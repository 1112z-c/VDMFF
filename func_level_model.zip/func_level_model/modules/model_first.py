import torch
from dgl.nn.pytorch import GatedGraphConv,GATConv,GraphConv,GATv2Conv
from torch import nn
import torch.nn.functional as f
import dgl

class xflat(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return torch.flatten(x, 1)

class xunsqueeze(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x.unsqueeze(dim=1)


class ALL_G(nn.Module):
    def __init__(self, input_dim, output_dim, max_edge_types=2, num_steps=6):
        super(ALL_G, self).__init__()
        self.inp_dim = input_dim
        self.out_dim = output_dim
        self.max_edge_types = max_edge_types
        self.num_timesteps = num_steps
        self.ggnn = GatedGraphConv(in_feats=input_dim, out_feats=output_dim,
                                   n_steps=num_steps, n_etypes=max_edge_types)
        self.conv_l1 = torch.nn.Conv1d(output_dim,300, 3)
        self.maxpool1 = torch.nn.MaxPool1d(3, stride=2)
        self.conv_l2 = torch.nn.Conv1d(300, 300, 1)
        self.maxpool2 = torch.nn.MaxPool1d(2, stride=2)

        self.concat_dim = input_dim + output_dim
        self.conv_l1_for_concat = torch.nn.Conv1d(300, 300, 3)
        self.maxpool1_for_concat = torch.nn.MaxPool1d(3, stride=2)
        self.conv_l2_for_concat = torch.nn.Conv1d(300, 300, 1)
        self.maxpool2_for_concat = torch.nn.MaxPool1d(2, stride=2)

        self.batchnorm_1d = torch.nn.BatchNorm1d(300)
        self.batchnorm_1d_for_concat = torch.nn.BatchNorm1d(300)


        self.conv1 = nn.Conv1d(in_channels=768, out_channels=512, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(in_channels=512, out_channels=300, kernel_size=3, padding=1)
        self.max_pool = nn.MaxPool1d(kernel_size=1, stride=1)
        self.dropout = nn.Dropout(p=0.3)
        self.to_liner = nn.Linear(300, 1, bias=False)
        self.batch_norm = nn.BatchNorm1d(300)
        self.to_text_latent2 = nn.Linear(300, 300, bias=False)


        self.conv_2d1 = nn.Conv2d(3, 100, (3, 128), stride=1)
        self.conv_2d2 =  nn.Conv2d(100,100,(3,1),stride=1)
        self.conv_image1 = torch.nn.Conv1d(100, 300, 3)
        self.conv_image2 = torch.nn.Conv1d(300, 300, 3)
        self.padding1 = nn.ZeroPad2d((0, 0, 1, 1))
        self.relu = nn.ReLU()


        self.classifier = nn.Linear(in_features=903, out_features=2)


    def image_extractor(self, x):

        x = x.float()
        x = self.conv_2d1(x)
        x = self.padding1(x)
        x1 = self.relu(x)

        x = self.conv_2d2(x1)
        x = self.padding1(x)
        x2 = self.relu(x)

        x = x1 + x2

        x = torch.squeeze(x,dim=3)
        x = self.conv_image1(x)
        x = self.relu(x)
        x = self.maxpool1(x)
        x = self.conv_image2(x)
        x = self.relu(x)
        x = self.maxpool2(x)
        x = x.sum(dim=2)

        return x

    def text_extractor(self, x):

        x = x.permute(0, 2, 1)
        x = torch.nn.functional.relu(self.conv1(x))
        x = self.max_pool(x)
        x = torch.nn.functional.relu(self.conv2(x))
        x = self.max_pool(x)
        x = torch.sum(x,dim=2)
        x = self.dropout(x)

        x = torch.nn.functional.normalize(self.to_text_latent2(x))
        x = self.batch_norm(x)
        x = torch.nn.functional.normalize(self.to_text_latent2(x))
        x = self.batch_norm(x)
        return x

    def forward(self, input_ids, image, batch):
        graph, features, edge_types = batch.get_network_inputs()
        outputs = self.ggnn(graph, features, edge_types)
        x_i, _ = batch.de_batchify_graphs(features)
        h_i, _ = batch.de_batchify_graphs(outputs)
        c_i = torch.cat((h_i, x_i), dim=-1)
        batch_size, num_node, _ = c_i.size()
        Y_1 = self.maxpool1(
            f.relu(
                self.batchnorm_1d(
                    self.conv_l1(h_i.transpose(1, 2))
                )
            )
        )
        Y_2 = self.maxpool2(
            f.relu(
                self.batchnorm_1d(
                    self.conv_l2(Y_1)
                )

            )
        )
        Z_1 = self.maxpool1_for_concat(
            f.relu(
                self.batchnorm_1d_for_concat(
                    self.conv_l1_for_concat(c_i.transpose(1, 2))
                )
            )
        )
        Z_2 = self.maxpool2_for_concat(
            f.relu(
                self.batchnorm_1d_for_concat(
                    self.conv_l2_for_concat(Z_1)
                )
            )
        )

        before_avg = torch.mul(Y_2, Z_2)
        graph = before_avg.mean(dim=2)
        text = self.text_extractor(input_ids)
        image = self.image_extractor(image)


        x_g = self.to_liner(graph)
        x_t = self.to_liner(text)
        x_i = self.to_liner(image)


        g = torch.cat((graph, x_g), 1)
        t = torch.cat((text, x_t), 1)
        i = torch.cat((image, x_i), 1)

        x = torch.cat((g,t,i),1)
        avg = self.classifier(x)

        return avg, x