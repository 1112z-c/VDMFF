import math
import torch
from dgl.nn.pytorch import GatedGraphConv
from torch import nn
import torch.nn.functional as F


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 1024):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # [1, max_len, d_model]
        self.register_buffer('pe', pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, L, D]
        seq_len = x.size(1)
        return x + self.pe[:, :seq_len, :]


class LocalAttentionBlock(nn.Module):
    """
    位置编码 -> 多头自注意力 -> 残差归一化 -> 前馈网络 -> 残差归一化
    """
    def __init__(self, d_model: int = 300, num_heads: int = 3, ff_dim: int = 300, dropout: float = 0.1):
        super().__init__()
        self.pos_encoder = PositionalEncoding(d_model)
        self.self_attn = nn.MultiheadAttention(d_model, num_heads, dropout=dropout, batch_first=True)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, ff_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(ff_dim, d_model)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.pos_encoder(x)
        attn_out, _ = self.self_attn(x, x, x)
        x = self.norm1(x + self.dropout(attn_out))
        ffn_out = self.ffn(x)
        x = self.norm2(x + self.dropout(ffn_out))
        return x


class CrossModalAttentionBlock(nn.Module):
    """
    Q 来自当前模态，K/V 来自另一模态，随后接残差 + 归一化 + 前馈网络
    """
    def __init__(self, d_model: int = 300, num_heads: int = 3, ff_dim: int = 300, dropout: float = 0.1):
        super().__init__()
        self.q_norm = nn.LayerNorm(d_model)
        self.kv_norm = nn.LayerNorm(d_model)
        self.cross_attn = nn.MultiheadAttention(d_model, num_heads, dropout=dropout, batch_first=True)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.ffn = nn.Sequential(
            nn.Linear(d_model, ff_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(ff_dim, d_model)
        )

    def forward(self, query_x: torch.Tensor, kv_x: torch.Tensor) -> torch.Tensor:
        q = self.q_norm(query_x)
        kv = self.kv_norm(kv_x)
        attn_out, _ = self.cross_attn(q, kv, kv)
        x = self.norm1(query_x + self.dropout(attn_out))
        ffn_out = self.ffn(x)
        x = self.norm2(x + self.dropout(ffn_out))
        return x


class ALL_G(nn.Module):
    def __init__(self, input_dim, output_dim, max_edge_types=2, num_steps=6,
                 d_model: int = 300, num_heads: int = 3, ff_dim: int = 300, dropout: float = 0.1):
        super(ALL_G, self).__init__()
        self.inp_dim = input_dim
        self.out_dim = output_dim
        self.max_edge_types = max_edge_types
        self.num_timesteps = num_steps
        self.d_model = d_model

        # ===== 图模态编码器 =====
        self.ggnn = GatedGraphConv(in_feats=input_dim, out_feats=output_dim,
                                   n_steps=num_steps, n_etypes=max_edge_types)
        self.conv_l1 = nn.Conv1d(output_dim, 300, 3)
        self.maxpool1 = nn.MaxPool1d(3, stride=2)
        self.conv_l2 = nn.Conv1d(300, 300, 1)
        self.maxpool2 = nn.MaxPool1d(2, stride=2)

        self.concat_dim = input_dim + output_dim
        self.conv_l1_for_concat = nn.Conv1d(self.concat_dim, 300, 3)
        self.maxpool1_for_concat = nn.MaxPool1d(3, stride=2)
        self.conv_l2_for_concat = nn.Conv1d(300, 300, 1)
        self.maxpool2_for_concat = nn.MaxPool1d(2, stride=2)

        self.batchnorm_1d = nn.BatchNorm1d(300)
        self.batchnorm_1d_for_concat = nn.BatchNorm1d(300)

        # ===== 文本模态编码器 =====
        self.conv1 = nn.Conv1d(in_channels=768, out_channels=512, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(in_channels=512, out_channels=300, kernel_size=3, padding=1)
        self.max_pool = nn.MaxPool1d(kernel_size=1, stride=1)
        self.text_dropout = nn.Dropout(p=0.3)

        # ===== 图像模态编码器 =====
        self.conv_2d1 = nn.Conv2d(3, 100, (3, 128), stride=1)
        self.conv_2d2 = nn.Conv2d(100, 100, (3, 1), stride=1)
        self.conv_image1 = nn.Conv1d(100, 300, 3)
        self.conv_image2 = nn.Conv1d(300, 300, 3)
        self.padding1 = nn.ZeroPad2d((0, 0, 1, 1))
        self.relu = nn.ReLU()

        # ===== 特征处理层：把各模态统一到 d_model =====
        self.graph_proj = nn.Linear(300, d_model)
        self.text_proj = nn.Linear(300, d_model)
        self.image_proj = nn.Linear(300, d_model)

        # ===== 局部注意力模块 =====
        self.local_attn_g = LocalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)
        self.local_attn_t = LocalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)
        self.local_attn_i = LocalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)

        # ===== 跨模态注意力模块 =====
        self.cross_t_from_g = CrossModalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)
        self.cross_t_from_i = CrossModalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)

        self.cross_g_from_t = CrossModalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)
        self.cross_g_from_i = CrossModalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)

        self.cross_i_from_t = CrossModalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)
        self.cross_i_from_g = CrossModalAttentionBlock(d_model=d_model, num_heads=num_heads, ff_dim=ff_dim, dropout=dropout)

        # ===== 分类器 =====
        self.classifier = nn.Sequential(
            nn.Linear(d_model * 3, d_model),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, 2)
        )

    def image_extractor(self, x):
        """
        返回 image_seq: [B, L_i, 300]
        """
        x = x.float()
        x = self.conv_2d1(x)
        x = self.padding1(x)
        x1 = self.relu(x)

        x = self.conv_2d2(x1)
        x = self.padding1(x)
        x2 = self.relu(x)

        x = x1 + x2
        x = torch.squeeze(x, dim=3)          # [B, 100, L]
        x = self.conv_image1(x)              # [B, 300, L']
        x = self.relu(x)
        x = self.maxpool1(x)
        x = self.conv_image2(x)              # [B, 300, L'']
        x = self.relu(x)
        x = self.maxpool2(x)                 # [B, 300, L''']

        image_seq = x.transpose(1, 2)        # [B, L_i, 300]
        image_seq = self.image_proj(image_seq)
        return image_seq

    def text_extractor(self, x):
        """
        返回 text_seq: [B, L_t, 300]
        """
        x = x.permute(0, 2, 1)               # [B, 768, L]
        x = F.relu(self.conv1(x))
        x = self.max_pool(x)
        x = F.relu(self.conv2(x))            # [B, 300, L]
        x = self.max_pool(x)
        x = self.text_dropout(x)

        text_seq = x.transpose(1, 2)         # [B, L_t, 300]
        text_seq = self.text_proj(text_seq)
        return text_seq

    def graph_extractor(self, batch):
        """
        返回 graph_seq: [B, L_g, 300]
        """
        graph, features, edge_types = batch.get_network_inputs()
        outputs = self.ggnn(graph, features, edge_types)
        x_i, _ = batch.de_batchify_graphs(features)
        h_i, _ = batch.de_batchify_graphs(outputs)
        c_i = torch.cat((h_i, x_i), dim=-1)

        y_1 = self.maxpool1(
            F.relu(
                self.batchnorm_1d(
                    self.conv_l1(h_i.transpose(1, 2))
                )
            )
        )
        y_2 = self.maxpool2(
            F.relu(
                self.batchnorm_1d(
                    self.conv_l2(y_1)
                )
            )
        )
        z_1 = self.maxpool1_for_concat(
            F.relu(
                self.batchnorm_1d_for_concat(
                    self.conv_l1_for_concat(c_i.transpose(1, 2))
                )
            )
        )
        z_2 = self.maxpool2_for_concat(
            F.relu(
                self.batchnorm_1d_for_concat(
                    self.conv_l2_for_concat(z_1)
                )
            )
        )

        graph_feat = torch.mul(y_2, z_2)     # [B, 300, L_g]
        graph_seq = graph_feat.transpose(1, 2)
        graph_seq = self.graph_proj(graph_seq)
        return graph_seq

    def forward(self, input_ids, image, batch, **kwargs):
        # 1) 三个模态各自提取序列特征
        graph_seq = self.graph_extractor(batch)
        text_seq = self.text_extractor(input_ids)
        image_seq = self.image_extractor(image)

        # 2) 局部注意力：建模单一模态内部依赖
        h_g_local = self.local_attn_g(graph_seq)
        h_t_local = self.local_attn_t(text_seq)
        h_i_local = self.local_attn_i(image_seq)

        # 3) 跨模态注意力：建模模态间信息交互
        h_t_cross = self.cross_t_from_g(h_t_local, h_g_local)
        h_t_cross = self.cross_t_from_i(h_t_cross, h_i_local)

        h_g_cross = self.cross_g_from_t(h_g_local, h_t_local)
        h_g_cross = self.cross_g_from_i(h_g_cross, h_i_local)

        h_i_cross = self.cross_i_from_t(h_i_local, h_t_local)
        h_i_cross = self.cross_i_from_g(h_i_cross, h_g_local)

        # 4) 池化得到模态级表示
        g_vec = h_g_cross.mean(dim=1)
        t_vec = h_t_cross.mean(dim=1)
        i_vec = h_i_cross.mean(dim=1)

        # 5) 拼接分类
        fused = torch.cat((g_vec, t_vec, i_vec), dim=1)
        logits = self.classifier(fused)

        return logits, fused
