import argparse
import os
import pickle
import sys
import joblib
import numpy as np
import torch
from torch.nn import BCELoss
from torch.optim import Adam

from data_loader.dataset import DataSet
from modules.model import GGNNSum,VuldetexpModel,EVD1, DevignModel,IVDetect,DeepWukong, ALL,ALL_G
from trainer import train, eval, show_representation
from utils import tally_param, debug
from transformers import (
                          BertConfig, BertForMaskedLM, BertTokenizer,
                          RobertaConfig, RobertaForSequenceClassification, RobertaTokenizer
                          )


if __name__ == '__main__':
    torch.manual_seed(22)
    np.random.seed(22)
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_type', type=str, help='Type of the model',
                        choices=['Vuldetexp', 'Devign','EVD1','IVDetect','Reveal1',"DeepWukong",'ALL','ALL_G'], default='ALL_G')
    parser.add_argument('--dataset', type=str, help='Name of the dataset for experiment.',default='devign')
    parser.add_argument('--input_dir', type=str, help='Input Directory of the parser',
                        default='/opt/data/VCM/data/tvtjson/chrome/')
    parser.add_argument('--node_tag', type=str, help='Name of the node feature.', default='node_features')
    parser.add_argument('--graph_tag', type=str, help='Name of the graph feature.', default='graph')
    parser.add_argument('--label_tag', type=str, help='Name of the label feature.', default='target')
    parser.add_argument('--text_emb', type=str, help='Name of the text feature.', default='text_embedding')
    parser.add_argument('--image_feature', type=str, help='Name of the image feature.', default='image_features')

    parser.add_argument('--feature_size', type=int, help='Size of feature vector for each node', default=100)
    parser.add_argument('--graph_embed_size', type=int, help='Size of the Graph Embedding', default=200)
    parser.add_argument('--num_steps', type=int, help='Number of steps in GGNN', default=6)
    parser.add_argument('--batch_size', type=int, help='Batch Size for training', default=32)
    parser.add_argument('--task', type=str, help='train or eval', default='train')

    args = parser.parse_args()
    if args.feature_size > args.graph_embed_size:
        print('Warning!!! Graph Embed dimension should be at least equal to the feature dimension.\n'
              'Setting graph embedding size to feature size', file=sys.stderr)
        args.graph_embed_size = args.feature_size


    input_dir = args.input_dir
    if args.task != 'eval':
        processed_data_path = os.path.join('/opt/data/VCM/data/', 'chrome_train_dataset.pkl')
        if True and os.path.exists(processed_data_path):
            print('*'*20)
            dataset = joblib.load(open(processed_data_path, 'rb'))
            debug('Reading already processed data from %s!' % processed_data_path)
        else:
            print('#'*20)
            dataset = DataSet(train_src=os.path.join(input_dir, 'train.txt'),
                              valid_src=os.path.join(input_dir, 'val.txt'),
                              test_src=None,
                              batch_size=args.batch_size, n_ident=args.node_tag, g_ident=args.graph_tag,
                              l_ident=args.label_tag, i_ident=args.image_feature, t_ident=args.text_emb,)
            file = open(processed_data_path, 'wb')
            joblib.dump(dataset, file)
            file.close()
    else:
        processed_data_path = os.path.join('/opt/data/VCM/data/', 'chrome_test_dataset.pkl')
        if True and os.path.exists(processed_data_path):
            print('*'*20)
            dataset = joblib.load(open(processed_data_path, 'rb'))
            debug('Reading already processed data from %s!' % processed_data_path)
        else:
            print('#'*20)
            dataset = DataSet(train_src=None,
                            valid_src=None,
                            test_src=os.path.join(input_dir, 'test.txt'),
                            batch_size=args.batch_size, n_ident=args.node_tag, g_ident=args.graph_tag,
                            l_ident=args.label_tag, i_ident=args.image_feature, t_ident=args.text_emb,)
            file = open(processed_data_path, 'wb')
            joblib.dump(dataset, file)
            file.close()

    assert args.feature_size == dataset.feature_size, \
        'Dataset contains different feature vector than argument feature size. ' \
        'Either change the feature vector size in argument, or provide different dataset.'

    print('---------------')

    model = ALL_G(input_dim=dataset.feature_size, output_dim=args.graph_embed_size, num_steps=6, max_edge_types=3)


    debug('Total Parameters : %d' % tally_param(model))
    debug('#' * 100)

    loss_function = torch.nn.CrossEntropyLoss()
    optim = Adam(model.parameters(), lr=0.0001, weight_decay=0.001)
    debug('batch size  : %d' % args.batch_size)
    debug('lr  : 0.0001')
    debug('weight_decay  : 0.001')
    model_dir = '/opt/data/VCM/data/savemodel/'
    if not os.path.exists(model_dir):
        os.makedirs(model_dir)
    if args.task != 'eval':
        train(model=model, dataset=dataset, max_steps=2000, dev_every=128,
              loss_function=loss_function, optimizer=optim,
              save_path=model_dir, max_patience=10, log_every=None, type=args.model_type)

    else:
        eval(model=model, dataset=dataset, loss_function=loss_function, save_path=model_dir, type=args.model_type)

