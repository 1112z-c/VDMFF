import copy
import numpy as np
import torch
from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score,roc_auc_score,matthews_corrcoef
from utils import debug
from tsne import  plot_embedding


def evaluate_loss(model, loss_function, num_batches, data_iter):
    model.eval()
    with torch.no_grad():
        _loss = []
        all_predictions, all_targets = [], []
        for _ in range(num_batches):
            graph, text, image, targets = data_iter()
            predictions,rep_2d = model(input_ids=text, image=image, batch=graph, cuda=False,text_join=True, graph_join=True, image_join=True)
            targets = targets.long()
            batch_loss = loss_function(predictions, targets)

            _loss.append(batch_loss.detach().cpu().item())
            predictions = predictions.detach().cpu()
            if predictions.ndim == 2:
                all_predictions.extend(np.argmax(predictions.numpy(), axis=-1).tolist())
            else:
                all_predictions.extend(
                    predictions.ge(torch.ones(size=predictions.size()).fill_(0.5)).to(
                        dtype=torch.int32).numpy().tolist()
                )
            all_targets.extend(targets.detach().cpu().numpy().tolist())
        model.train()
        return np.mean(_loss).item(), f1_score(all_targets, all_predictions) * 100, accuracy_score(all_targets, all_predictions) * 100
    pass


def train(model, dataset, max_steps, dev_every, loss_function, optimizer, save_path, log_every=50, max_patience=5, type='ALL'):
    debug('Start Training')
    train_losses = []
    best_model = None
    patience_counter = 0
    best_f1 = 0
    best_acc = 0
    f11 = []
    accc = []
    step = []
    t_loss = []
    v_loss = []
    try:
        for step_count in range(max_steps):
            model.train()
            model.zero_grad()
            graph, text, image, targets = dataset.get_next_train_batch()

            targets =targets.long()
            predictions,rep_2d = model(input_ids=text, image=image, batch=graph) #开始forward

            batch_loss = loss_function(predictions, targets)
            if log_every is not None and (step_count % log_every == log_every - 1):
                debug('Step %d\t\tTrain Loss %10.3f' % (step_count, batch_loss.detach().cpu().item()))
            train_losses.append(batch_loss.detach().cpu().item())
            batch_loss.backward()
            optimizer.step()
            if step_count % dev_every == (dev_every - 1):
                valid_loss, valid_f1 ,valid_acc = evaluate_loss(model, loss_function, dataset.initialize_valid_batch(),dataset.get_next_valid_batch)
                step.append(step_count)
                t_loss.append(batch_loss.detach().cpu().item())
                v_loss.append(valid_loss)
                f11.append(valid_f1)
                accc.append(valid_acc)

                if valid_f1 > 67.0 and valid_f1 > best_f1:
                    patience_counter = 0
                    best_f1 = valid_f1
                    best_model = copy.deepcopy(model.state_dict())
                    ckptname = '2024-' + str(dataset.batch_size) + '-' + str(valid_acc) + '-' + str(
                        valid_f1) + '-' + type + '.ckpt'
                    _save_ckpt_file = open(save_path  + ckptname, 'wb')
                    torch.save(model.state_dict(), _save_ckpt_file)
                    _save_ckpt_file.close()
                else:
                    patience_counter += 1
                debug('Step %d\t\tTrain Loss %10.3f\tValid Loss%10.3f\tf1: %5.2f\tacc: %5.2f\tPatience %d' % (step_count, np.mean(train_losses).item(), valid_loss, valid_f1, valid_acc, patience_counter))
                debug('=' * 100)
                train_losses = []
                if patience_counter == max_patience:
                    break
    except KeyboardInterrupt:
        debug('Training Interrupted by user!')
    if best_model is not None:
        model.load_state_dict(best_model)
    _save_ckpt_file = open(save_path + type+ '_modelbest.ckpt', 'wb')
    torch.save(model.state_dict(), _save_ckpt_file)
    _save_ckpt_file.close()
    #
    debug('=' * 100)


def eval(model, dataset, loss_function, save_path, type):
    debug('Start eval')
    _save_ckpt_file = torch.load(save_path + type+ '_modelbest.ckpt')
    # model.load_state_dict(_save_ckpt_file['state_dict'])
    model.load_state_dict(_save_ckpt_file)
    acc, pr, rc, f1, auc, mcc = test_metrics(model, loss_function, dataset.initialize_test_batch(),dataset.get_next_test_batch)
    debug('%s\tTest Accuracy: %0.2f\tPrecision: %0.2f\tRecall: %0.2f\tF1: %0.2f\tAUC: %0.2f\tMCC: %0.2f' % (save_path, acc, pr, rc, f1, auc, mcc))
    debug('=' * 100)

def test_metrics(model, loss_function, num_batches, data_iter):
    model.eval()
    with torch.no_grad():
        _loss = []
        all_predictions, all_targets = [], []

        for _ in range(num_batches):
            graph, text, image, targets = data_iter()
            predictions,rep_2d = model(input_ids=text, image=image, batch=graph)

            predictions = predictions.detach().cpu()

            if predictions.ndim == 2:
                all_predictions.extend(np.argmax(predictions.numpy(), axis=-1).tolist())
            else:
                all_predictions.extend(
                    predictions.ge(torch.ones(size=predictions.size()).fill_(0.5)).to(
                        dtype=torch.int32).numpy().tolist()
                )
            all_targets.extend(targets.detach().cpu().numpy().tolist())

        model.train()


        return accuracy_score(all_targets, all_predictions) * 100, \
               precision_score(all_targets, all_predictions) * 100, \
               recall_score(all_targets, all_predictions) * 100, \
               f1_score(all_targets, all_predictions) * 100, \
               roc_auc_score(all_targets, all_predictions) * 100, \
               matthews_corrcoef(all_targets, all_predictions) * 100
        pass

