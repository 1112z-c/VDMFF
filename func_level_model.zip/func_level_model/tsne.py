import numpy as np
import matplotlib.pyplot as plt
from sklearn import manifold
from sklearn.model_selection import train_test_split
import seaborn as sns
sns.set(rc={'figure.figsize':(11.7,8.27)})
palette = sns.color_palette("bright", 2)
import json

#降维
def plot_embedding(s_X_org, s_y,type='ALL_G'):
    s_X, _, s_Y, _ = train_test_split(s_X_org, s_y, test_size=0.5)
    s_X, s_Y = np.asarray(s_X), np.asarray(s_Y)

    tsne = manifold.TSNE(n_components=2, init='pca', random_state=0)
    print('Fitting TSNE!')

    s_X = tsne.fit_transform(s_X)
    s_x_min, s_x_max = np.min(s_X, 0), np.max(s_X, 0)
    s_X = (s_X - s_x_min) / (s_x_max - s_x_min)

    file_ = open(type + '-tsne-features.json', 'w')
    if isinstance(s_X, np.ndarray):
        s_x = s_X.tolist()
        s_y = s_Y.tolist()

    else:
        s_x = s_X
        s_y = s_Y



    json.dump([s_x, s_y], file_)

    file_.close()
    fig, ax = plt.subplots()

    plt.ylim(0, 1.025)  # 不设置上面会有点超过边框
    plt.xlim(0, 1.02)
    # plt.figure("zcy")
    ax.text(0.3, 1.05, '0:',
            color=plt.cm.Set1(2),
            fontdict={'weight': 'bold', 'size': 20})
    ax.text(0.35, 1.05, 'Non-Vul',
            color=plt.cm.Set1(2),
            fontdict={'weight': 'bold', 'size': 20})
    ax.text(0.55, 1.05, '1:',
            color=plt.cm.Set1(0),  # red
            fontdict={'weight': 'bold', 'size': 20})
    ax.text(0.6, 1.05, 'Vul',
            color=plt.cm.Set1(0),
            fontdict={'weight': 'bold', 'size': 20})
    # sns.scatterplot(X[:, 0], X[:, 1], hue=y_v, palette=['red', 'green'])
    for i in range(s_X.shape[0]):
        if s_Y[i] == 0:
            ax.text(s_X[i, 0], s_X[i, 1], '0',
                     color=plt.cm.Set1(2),#hui color
                     fontdict={'size': 6})
            ax.set_facecolor('white')
        else:
            ax.text(s_X[i, 0], s_X[i, 1], '1',
                     color=plt.cm.Set1(0),#red
                     fontdict={'weight': 'bold', 'size': 9})
            ax.set_facecolor('white')




    ax.spines['top'].set_linewidth('1.5')  # 设置边框宽度
    ax.spines['top'].set_linestyle("-")  # 设置边框样式
    ax.spines['top'].set_color('black')  # 设置边框颜色
    ax.spines['bottom'].set_linewidth('1.0')
    ax.spines['bottom'].set_linestyle("-")
    ax.spines['bottom'].set_color('black')
    ax.spines['right'].set_linewidth('1.0')
    ax.spines['right'].set_linestyle("-")
    ax.spines['right'].set_color('black')
    ax.spines['left'].set_linewidth('1.0')
    ax.spines['left'].set_linestyle("-")
    ax.spines['left'].set_color('black')


    plt.xticks([]), plt.yticks([])

    plt.savefig(type + '.pdf',dpi=300,bbox_inches='tight')
    plt.show()


