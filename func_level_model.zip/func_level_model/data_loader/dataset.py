import os
import copy
import json
import sys
import numpy
import torch
from dgl import DGLGraph
from tqdm import tqdm
from data_loader.batch_graph import GGNNBatchGraph
from func_level_model.utils import load_default_identifiers, initialize_batch, debug

import random


class DataEntry:
    def __init__(self, datset, num_nodes, features, edges, target,text, image):
        self.dataset = datset
        self.num_nodes = num_nodes
        self.target = target
        self.graph = DGLGraph()
        self.features = torch.FloatTensor(features)
        self.text = torch.FloatTensor(text)
        self.image = torch.FloatTensor(image)
        self.graph.add_nodes(self.num_nodes, data={"features": self.features})
        for s, _type, t in edges:
            etype_number = self.dataset.get_edge_type_number(_type)
            self.graph.add_edge(s, t, data={"etype": torch.LongTensor([etype_number])})


class DataSet:
    def __init__(self, train_src, valid_src=None, test_src=None, batch_size=32, n_ident=None, g_ident=None, l_ident=None,t_ident =None,i_ident =None):
        self.train_examples = []
        self.valid_examples = []
        self.test_examples = []
        self.train_batches = []
        self.valid_batches = []
        self.test_batches = []
        self.batch_size = batch_size
        self.edge_types = {}
        self.max_etype = 0
        self.feature_size = 100
        self.n_ident, self.g_ident, self.l_ident,self.t_ident,self.i_indent= load_default_identifiers(n_ident, g_ident, l_ident, t_ident, i_ident)
        self.read_dataset(test_src, train_src, valid_src)
        self.initialize_dataset()

    def initialize_dataset(self):
        self.initialize_train_batch()
        self.initialize_valid_batch()
        self.initialize_test_batch()

    def read_dataset(self, test_src, train_src, valid_src):
        if train_src is not None:
            debug('Reading Train File!',train_src)
            with open(train_src) as fp:
                path_list = fp.readlines()
                for path in tqdm(path_list):
                    with open(path.strip(), 'r') as json_file:
                        pdg = json.load(json_file)
                        if len(pdg[self.n_ident]) == 0 or len(pdg[self.n_ident]) < 9:
                            continue
                        if pdg[self.i_indent] is not None:
                            example = DataEntry(datset=self, num_nodes=len(pdg[self.n_ident]), features=pdg[self.n_ident],
                                        edges=pdg[self.g_ident], target=pdg[self.l_ident],text = pdg[self.t_ident],image = pdg[self.i_indent])
                        if self.feature_size == 0:
                            self.feature_size = example.features.size(1)
                            debug('Feature Size %d' % self.feature_size)
                        self.train_examples.append(example)
            random.shuffle(self.train_examples)
        #
        if valid_src is not None:
            debug('Reading Validation File!')
            with open(valid_src) as fp:
                path_list = fp.readlines()
                for path in tqdm(path_list):
                    with open(path.strip(), 'r') as json_file:
                        pdg = json.load(json_file)
                        if len(pdg[self.n_ident]) == 0 or len(pdg[self.n_ident]) < 9:
                            continue
                        if pdg[self.i_indent] is not None:
                            example = DataEntry(datset=self, num_nodes=len(pdg[self.n_ident]), features=pdg[self.n_ident],
                                            edges=pdg[self.g_ident], target=pdg[self.l_ident], text=pdg[self.t_ident],
                                            image=pdg[self.i_indent])
                        if self.feature_size == 0:
                            self.feature_size = example.features.size(1)
                            debug('Feature Size %d' % self.feature_size)
                        self.valid_examples.append(example)

            random.shuffle(self.valid_examples)
        if test_src is not None:
            record_txt = []
            debug('Reading Test File!',test_src)
            with open(test_src) as fp:
                path_list = fp.readlines()
                for path in tqdm(path_list):
                    with open(path.strip(), 'r') as json_file:
                        pdg = json.load(json_file)
                        if len(pdg[self.n_ident]) == 0 or len(pdg[self.n_ident]) < 9:
                            continue
                        if pdg[self.i_indent] is not None:
                            example = DataEntry(datset=self, num_nodes=len(pdg[self.n_ident]), features=pdg[self.n_ident],
                                            edges=pdg[self.g_ident], target=pdg[self.l_ident], text=pdg[self.t_ident],
                                            image=pdg[self.i_indent])
                        self.test_examples.append(example)
                        record_txt.append(path)
            random.shuffle(self.valid_examples)

    def get_edge_type_number(self, _type):
        if _type not in self.edge_types:
            self.edge_types[_type] = self.max_etype
            self.max_etype += 1
        return self.edge_types[_type]

    @property
    def max_edge_type(self):
        return self.max_etype

    def initialize_train_batch(self, batch_size=-1):
        if batch_size == -1:
            batch_size = self.batch_size
        self.train_batches = initialize_batch(self.train_examples, batch_size, shuffle=True)
        return len(self.train_batches)
        pass

    def initialize_valid_batch(self, batch_size=-1):
        if batch_size == -1:
            batch_size = self.batch_size
        self.valid_batches = initialize_batch(self.valid_examples, batch_size)
        return len(self.valid_batches)
        pass

    def initialize_test_batch(self, batch_size=-1):
        if batch_size == -1:
            batch_size = self.batch_size
        self.test_batches = initialize_batch(self.test_examples, batch_size)
        return len(self.test_batches)
        pass

    def get_dataset_by_ids_for_GGNN(self, entries, ids):
        taken_entries = [entries[i] for i in ids]
        labels = [e.target for e in taken_entries]
        batch_graph = GGNNBatchGraph()
        #features_list=[]
        text_list =[]
        image_list=[]
        for entry in taken_entries:
            batch_graph.add_subgraph(copy.deepcopy(entry.graph))

            text_list.append(entry.text)

            image_list.append(entry.image)

            feature_dim = max(text.size(1) for text in text_list)  # 特征维度

            text_list_padded = []
            for text in text_list:

                padding_size = 512 - text.size(0)
                if padding_size > 0:
                    padding = torch.zeros((padding_size, text.size(1)), device=text.device)  # 确保特征维度一致
                    text_padded = torch.cat((text, padding), dim=0)
                else:
                    text_padded = text
                if text_padded.size(1) < feature_dim:
                    additional_padding = torch.zeros((text_padded.size(0), feature_dim - text_padded.size(1)),
                                                     device=text.device)
                    text_padded = torch.cat((text_padded, additional_padding), dim=1)
                text_list_padded.append(text_padded)
            text = torch.stack(text_list_padded)

            image_list_padded = []

            for image in image_list:
                padding_size = 150 - image.size(1)

                if padding_size < 0:

                    padded_image = image[:, :150, :, :]
                else:
                    padding = torch.zeros((image.size(0), padding_size, image.size(2), image.size(3)),
                                          device=image.device)
                    padded_image = torch.cat((image, padding), dim=1)
                image_list_padded.append(padded_image)
            image = torch.stack(image_list_padded)
            image = torch.squeeze(image, dim=3)
        return batch_graph, text, image, torch.FloatTensor(labels)

    def get_next_train_batch(self):
        if len(self.train_batches) == 0:
            self.initialize_train_batch()
        ids = self.train_batches.pop()
        return self.get_dataset_by_ids_for_GGNN(self.train_examples, ids)

    def get_next_valid_batch(self):
        if len(self.valid_batches) == 0:
            self.initialize_valid_batch()
        ids = self.valid_batches.pop()
        return self.get_dataset_by_ids_for_GGNN(self.valid_examples, ids)

    def get_next_test_batch(self):
        if len(self.test_batches) == 0:
            self.initialize_test_batch()
        ids = self.test_batches.pop()
        return self.get_dataset_by_ids_for_GGNN(self.test_examples, ids)